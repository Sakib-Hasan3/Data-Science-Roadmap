#data type

#logical

x = TRUE
print(x)
print(class(x)) # Check the class of x
is.vector(x)    # Check if x is a vector

#numeric data typr

y=100.3
print(y)
print(class(y)) # Check the class of x

#integar data type

z=100L
print(z)
print(class(z)) # Check the class of x

#complex data type 
#a+bi

a=2+3i
print(a)
print(class(a))

#character data type

b="'345'"
print(b)
print(class(b))

#raw data type

c=charToRaw('study mart')
print(c)
print(class(c))