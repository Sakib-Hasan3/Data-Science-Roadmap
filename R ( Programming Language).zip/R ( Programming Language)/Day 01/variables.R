#variables

x=10
print(x) #simple number variable declare

y='data science'
print(y) #string variable declare 

#underscore variable declare

z_=40
print(z_)
print(class(z_)) #class is used to see the type of variable



#assign function

assign('x',60) #assign('variable name',value)
print(x)


#finding variable

print(ls()) #ls() is used to see all the variables which is declaed

#delete variables

rm(x) ##rm() is used to delete any variable
print(ls())