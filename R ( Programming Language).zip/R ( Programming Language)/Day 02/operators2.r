#assignment opeartor 

x=c(1,2,3) #left assignment
y<-x
print(x)
print(y)


x=c(1,2,3)  #right assignment
y>-x
print(x)
print(y)


#logical operator

x=c(1,2,3) 
y=c(1,3,5)
print(x && y)


x=c(1,2,3) 
y=c(1,3,5)
print(x || y)

x=c(1,2,3) 
y=c(1,3,5)
print(x & y)

x=c(1,2,3) 
y=c(1,3,5)
print(x | y)

x=c(1,2,3) 
y=c(1,3,5)
print(!x)
