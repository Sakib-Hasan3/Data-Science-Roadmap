#swapping opeartor

c=50
d=60

c,d=d,c
print("This value is C" ,c)
print("This value is d" ,d)