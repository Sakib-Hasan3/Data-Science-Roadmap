#loops in python

#while loop in python

x=0
while x<5:
    print("yes x is less than 10")
    x=x+1
    
#for loop in python

x = 5
for i in range(0, 5):
    print("This is Bangladesh")
    
#another for loop 

y={1,2,3,4,5,6}
for i  in y:
    print(i)
   
   
   #another for loop with string
    
fruits =["apple","banana","cherry"]
for x in fruits:
    print(x)
    
