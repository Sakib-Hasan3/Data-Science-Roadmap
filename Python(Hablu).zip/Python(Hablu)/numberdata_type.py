#int data type

x=420
print(x)

print(type(x)) #which type of data define

#float data type 

y=20.4
print(y)

print(type(y)) #which type of data define

#complex type data
#with j all other data types are complex

z=420j
print(z)

print(type(z))