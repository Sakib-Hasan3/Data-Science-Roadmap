#zip list in python

list1 = ("x", "y", "z", "k")
list2 = ("a", "b", "c")

print(list(zip(list1, list2)))
