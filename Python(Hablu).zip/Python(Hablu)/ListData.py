#list Data type

li=[1,2,3]
print(type(li))
print(li)

#another way 

li=["A","B","C"]
print(type(li))
print(li)


#change index variable 

li=[1,2,3]
li[1]=10
print(type(li))
print(li)


#boolean string 

list=[True,False,True,True]
print(type(list))
print(list)
