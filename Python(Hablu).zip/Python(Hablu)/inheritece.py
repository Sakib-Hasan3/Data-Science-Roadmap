class Baba:
    car = "Bmw"
    tk = "100 crore"
    home = "10 floor"
    
class Kaka(Baba):
    BrokenPhone = " "
    BrokenHome = " "
    
# Create an instance of Kaka and print the inherited car attribute
k = Kaka()
print(k.car)

# Create an instance of Baba
b = Baba()
