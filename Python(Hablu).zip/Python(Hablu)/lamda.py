#defining the anonymous function


#normal function type
def x(a,b) :
    sum=a+b
    print(sum)
    
x(10,20)
x(20,40)

#lamda function

y=lambda a,b,c,d: a+b+c+d
print(y(50,20,10,15)) 