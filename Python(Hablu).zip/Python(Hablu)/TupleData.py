#tuple data type in python

NewTuples=(1,2,3,"eshan",False) #list data is not changeable in tuple

print(type(NewTuples))


#no variable can be changed

NewTuples[1]=20
print(NewTuples)

#negative index
#-1 means the last number of list

xTuples=(1,2,"Sakib","eshan","False")
print(xTuples[-1])

