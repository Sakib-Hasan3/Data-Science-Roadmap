# Module.py
def hablu():
    print("hello, world")

def gablu():
    print("goodbye, world")

def eshan():
    print("hello, eshan")



person ={
    "name ": "sakib",
    "age":36,
    "city" :"dhaka"
}