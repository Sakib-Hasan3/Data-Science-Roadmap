#if else condition in python

#one condition 

a=30
b=10

if b>a :
    print("b is greater than a")
    
else : 
    print("a is greater than b")
    
#another condition 

a=20
b=10

if b==a:
    print("b is equal to a")
    
else : 
    print("a is not equal to b")
    
    
#another way 
  
a=30
b=30

if b!=a :
    print("b is not equal to a")
    
else : 
    print("a is equal to b")
    
    