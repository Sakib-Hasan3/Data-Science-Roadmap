#if else condition for loop

x ={
    "name": "John",
    "age": 30,
    "city" : "london"
}

x.get("city")
print(x)

#another way to do it

print(x.get("city"))


#update disctionaries

x["city"] = "new york"
print(x)

