import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FFMpegWriter

# Parameters for the flower
radii = np.linspace(0, 2 * np.pi, 500)  # Radii for the flower pattern
frames = 100  # Number of frames in the video

# Create the figure
fig, ax = plt.subplots(figsize=(6, 6))
ax.set_xlim(-2, 2)
ax.set_ylim(-2, 2)
ax.axis("off")  # Hide axes
line, = ax.plot([], [], lw=2, color="magenta")

# Function to create the flower pattern
def generate_flower(t):
    r = np.sin(6 * radii + t)  # Adjust the number of petals with the multiplier
    x = r * np.cos(radii)
    y = r * np.sin(radii)
    return x, y

# Initialize the plot
def init():
    line.set_data([], [])
    return line,

# Update function for animation
def update(frame):
    x, y = generate_flower(frame * 0.1)
    line.set_data(x, y)
    return line,

# Set up the writer for the video
metadata = dict(title="Flower Animation", artist="Matplotlib", comment="Flower-like animation")
writer = FFMpegWriter(fps=30, metadata=metadata)

# Animate and save the video
with writer.saving(fig, "flower_animation.mp4", dpi=100):
    for frame in range(frames):
        update(frame)
        writer.grab_frame()

plt.close()
