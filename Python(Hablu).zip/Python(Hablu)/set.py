#set in python

x= {1,True,"a","c"} 
print(x)#set items are changeable but you can remove or add item

#another way 

x= {1,False,"a","a"} 

print(x)

print(type(x))

print(len(x))