#string data type using double  quotes

name5="hjdkfhjkshk"
print(name5)