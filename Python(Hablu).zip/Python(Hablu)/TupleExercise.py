x = ("a", "b", "c")
print(x[0])          # Accessing the first element of the tuple

print(len(x))        # Getting the length of the tuple

y = x.count("a")     # Counting occurrences of "a" in the tuple
print(y)

z = x.index(2)       # Trying to find the index of 2 in the tuple
print(z)
