#print the second elements in the list

fruits =["apple","bannana","cherry"]
print(fruits[1])


#change value apple  to orange in the list 

fruits =["apple","bannana","cherry"]
fruits[0]="orange" 
print(fruits)

#add the append method and kiwi int the list

fruits =["apple","bannana","cherry"]
fruits.append("kiwi")
print(fruits)