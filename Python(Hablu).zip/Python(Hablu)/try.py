#try block lets you test a block of code for errors
#except block lets you handle the error
#else block lets you execute code when there is no error 
#finally block lets you execute code,regardless of the result of the try and except blocks

print("give me output")

try:
    print("give me output number 1 line")
except: #this is used to ignore the wrong input 
    print("yourr net is slow")
print("give me function")

print("give me 500 lines code")
print("give me 500 lines code")
