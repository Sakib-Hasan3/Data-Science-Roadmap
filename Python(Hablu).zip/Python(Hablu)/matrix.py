matrix = [
    [1, 2, 3],   # Row 1
    [4, 5, 6],   # Row 2
    [7, 8, 9]    # Row 3
]

# Accessing elements
print(matrix[0][1])  # 2 (first row, second column)

# Iterating through the matrix
for row in matrix:
    print(row)

# Printing all elements
for row in matrix:
    for element in row:
        print(element, end=" ")
    print()  # Newline after each row
