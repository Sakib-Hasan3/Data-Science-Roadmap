#copy a list in python

x=[1,2,3,4,5,6,7,8]
y=x.copy()
print("The previous list is :" ,x)

print("The copied list is : ",y)