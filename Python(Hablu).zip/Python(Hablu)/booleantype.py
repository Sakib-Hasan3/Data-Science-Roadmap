#boolean data type

Bool= True   #true is defined with Alphabetic letter T
print(Bool)

print(type(Bool))

#another examle 

bool= False   #true is defined with Alphabetic letter T
print(bool)

print(type(bool))

#another example 

x=8
y=10

print(x>y)

print(type(x>y))

#another example 

x=10
y=10
print(x==y)