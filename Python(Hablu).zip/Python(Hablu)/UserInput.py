#input from user

username=input()
print(username)


#another way


username=input("Enter your username : ")
password=input("Enter your password :")
print(username)
print(password)
