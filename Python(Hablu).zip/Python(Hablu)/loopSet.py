#loop set item in python

x={1,2,3,4}

for i in x :
    print(i)